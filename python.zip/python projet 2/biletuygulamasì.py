import sqlite3
from database import create_connection, create_tables

def add_flight(connection, flight_number, origin, destination, departure_time, arrival_time, price):
    with connection:
        cursor = connection.cursor()
        cursor.execute("""
            INSERT INTO flights (flight_number, origin, destination, departure_time, arrival_time, price)
            VALUES (?, ?, ?, ?, ?, ?)
        """, (flight_number, origin, destination, departure_time, arrival_time, price))
        print("Uçuş eklendi.")

def book_flight(connection, flight_id, passenger_name, passenger_email):
    with connection:
        cursor = connection.cursor()
        cursor.execute("""
            INSERT INTO bookings (flight_id, passenger_name, passenger_email)
            VALUES (?, ?, ?)
        """, (flight_id, passenger_name, passenger_email))
        print("Rezervasyon yapıldı.")

def view_bookings(connection):
    with connection:
        cursor = connection.cursor()
        cursor.execute("SELECT * FROM bookings")
        bookings = cursor.fetchall()
        for booking in bookings:
            print(booking)

def main():
    conn = create_connection()
    create_tables(conn)

    while True:
        print("\n1. Uçuş Ekle")
        print("\n2. Rezervasyon Yap")
        print("\n3. Rezervasyonları Görüntüle")
        print("\n4. Çıkış")
        choice = input("\nBir seçenek girin: ")

        if choice == '1':
            flight_number = input("Uçuş Numarası: ")
            origin = input("Kalkış Yeri: ")
            destination = input("Varış Yeri: ")
            departure_time = input("Kalkış Zamanı: ")
            arrival_time = input("Varış Zamanı: ")
            price = float(input("Fiyat: "))
            add_flight(conn, flight_number, origin, destination, departure_time, arrival_time, price)
        elif choice == '2':
            flight_id = int(input("Uçuş ID: "))
            passenger_name = input("Yolcu Adı: ")
            passenger_email = input("Yolcu E-posta: ")
            book_flight(conn, flight_id, passenger_name, passenger_email)
        elif choice == '3':
            view_bookings(conn)
        elif choice == '4':
            break
        else:
            print("Geçersiz seçenek. Lütfen tekrar deneyin.")

if __name__ == "__main__":
    main()
