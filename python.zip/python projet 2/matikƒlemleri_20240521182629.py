 #Matematik işlemleri#

def toplama(a, b):
    return a + b

def cikarma(a, b):
    return a - b

def carpma(a, b):
    return a * b

def bolme(a, b):
    if b == 0:
        return "Sıfıra bölme hatası!"
    return a / b

def matematik_islem():
    print("Matematik İşlem Uygulamasına Hoş Geldiniz!")
    print("Yapmak istediğiniz işlemi seçin:")
    print("1. Toplama")
    print("2. Çıkarma")
    print("3. Çarpma")
    print("4. Bölme")

    while True:
        secim = input("Seçiminizi yapın (1/2/3/4): ")

        if secim in ['1', '2', '3', '4']:
            try:
                sayi1 = float(input("Birinci sayıyı girin: "))
                sayi2 = float(input("İkinci sayıyı girin: "))
            except ValueError:
                print("Geçersiz giriş! Lütfen bir sayı girin.")
                continue

            if secim == '1':
                print(f"{sayi1} + {sayi2} = {toplama(sayi1, sayi2)}")
            elif secim == '2':
                print(f"{sayi1} - {sayi2} = {cikarma(sayi1, sayi2)}")
            elif secim == '3':
                print(f"{sayi1} * {sayi2} = {carpma(sayi1, sayi2)}")
            elif secim == '4':
                sonuc = bolme(sayi1, sayi2)
                print(f"{sayi1} / {sayi2} = {sonuc}")
            break
        else:
            print("Geçersiz seçim! Lütfen 1, 2, 3 veya 4 girin.")

# Uygulamayı başlat
if __name__ == "__main__":
    matematik_islem()

