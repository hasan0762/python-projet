#Taş Kağıt Makas Oyunu #

import random

def get_computer_choice():
    return random.choice(["Taş", "Kağıt", "Makas"])

def get_user_choice():
    user_choice = input("Seçiminizi yapın (Taş, Kağıt, Makas): ").capitalize()
    while user_choice not in ["Taş", "Kağıt", "Makas"]:
        user_choice = input("Geçersiz seçim. Lütfen tekrar seçin (Taş, Kağıt, Makas): ").capitalize()
    return user_choice

def determine_winner(user_choice, computer_choice):
    if user_choice == computer_choice:
        return "Berabere!"
    elif (user_choice == "Taş" and computer_choice == "Makas") or \
         (user_choice == "Kağıt" and computer_choice == "Taş") or \
         (user_choice == "Makas" and computer_choice == "Kağıt"):
        return "Kazandınız!"
    else:
        return "Kaybettiniz!"

def play_game():
    user_choice = get_user_choice()
    computer_choice = get_computer_choice()
    print(f"Bilgisayarın seçimi: {computer_choice}")
    result = determine_winner(user_choice, computer_choice)
    print(result)

if __name__ == "__main__":
    play_game()
